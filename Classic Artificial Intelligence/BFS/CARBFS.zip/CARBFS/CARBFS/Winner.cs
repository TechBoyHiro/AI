﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CARBFS
{
    public class Winner
    {
        public string hash { get; set; }
        public int hashnumber { get; set; }
    }
}
