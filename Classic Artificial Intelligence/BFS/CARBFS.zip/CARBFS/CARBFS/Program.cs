﻿using System;
using System.Collections.Generic;

namespace CARBFS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Car Blocking Game :)");
            Console.WriteLine("Enter the number of cars");
            List<Car> Cars = new List<Car>();
            int counter = int.Parse(Console.ReadLine());
            for (int i = 0; i < counter; i++)
            {
                Car temp = new Car();
                char[] enter = Console.ReadLine().ToCharArray();
                temp.CarId = int.Parse(enter[0].ToString());
                if (enter[3].ToString() == "v")
                {
                    temp.StartRow = (int.Parse(enter[1].ToString()) + (int.Parse(enter[4].ToString()) - 1)) - 1;
                }
                else
                    temp.StartRow = int.Parse(enter[1].ToString()) - 1; 
                temp.StartColumn = int.Parse(enter[2].ToString()) - 1;
                temp.length = int.Parse(enter[4].ToString());
                string temp2 = enter[3].ToString();
                if (temp2 == "h")
                {
                    temp.Direction = Direction.Horizontal;
                }
                else temp.Direction = Direction.Vertical;
                Cars.Add(temp);
            }
            //Console.WriteLine("**********************************************************");

            //foreach (Car item in Cars)
            //{
            //    Console.WriteLine(item.CarId + "-" + item.StartRow + "-" + item.StartColumn + "-" + item.length + "-" + item.Direction.ToString());
            //}
            CarNode RootNode = new CarNode(Cars,null);
            BFS BFS = new BFS();
            BFS.bfs(RootNode);

        }
    }
}
