﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CARBFS
{
    public static class Counter
    {
        public static int counter { get; set; }
    }
}
