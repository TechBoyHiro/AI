import solver.BFS;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        //todo write here

        BFS bfs = new BFS();
        
    }

}
