package models;

import java.util.ArrayList;

public class Node {


    public ArrayList<Node> successor() {

    }


    public boolean isFinal() {

    }

    public long hash() {

    }

    public void printPath() {

    }

}
